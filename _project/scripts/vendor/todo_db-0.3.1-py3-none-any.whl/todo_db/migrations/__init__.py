"""Packaged SQLite migrations."""
